/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:22/05/2023
*Fecha de actualización:10/06/2023
*Descripción:Estaes la clase vista torneo donde se registra el torneo y 
*su categoria genera el torneo
 */
package view;

import controller.EquipoController;
import entity.Torneo;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class VistaTorneo extends javax.swing.JFrame {

   
    private final DefaultTableModel modeloTable;
    private Torneo torneo;

    private final EquipoController equipoController;
    private final MenuVista menuVista;

    public VistaTorneo(MenuVista menuVista) {
        initComponents();
       
        this.equipoController = new EquipoController();
        this.menuVista = menuVista;
        this.modeloTable = (DefaultTableModel) TablaTorneo.getModel();

        this.equipoController.mostrarRegistro(this.menuVista.listaEquipo, 
                modeloTable);
        
        setResizable(false);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Titulo = new javax.swing.JLabel();
        Titulo2 = new javax.swing.JLabel();
        NombreTorneo = new javax.swing.JTextField();
        Categoria1 = new javax.swing.JLabel();
        Categoria2 = new javax.swing.JComboBox<>();
        GenerarTorneo = new javax.swing.JButton();
        BotonRegistrar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaTorneo = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        Pizarron = new javax.swing.JTextArea();
        BotonRegresar = new javax.swing.JButton();
        Imagen = new javax.swing.JLabel();
        Anuncio = new javax.swing.JLabel();
        Contenedor = new javax.swing.JLabel();
        wallpaper = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Titulo.setFont(new java.awt.Font("Waree", 1, 36)); // NOI18N
        Titulo.setText("Torneo");
        jPanel1.add(Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 10, 150, 50));

        Titulo2.setFont(new java.awt.Font("Waree", 1, 18)); // NOI18N
        Titulo2.setText("Ingrese el nombre del torneo");
        jPanel1.add(Titulo2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 80, 300, 30));
        jPanel1.add(NombreTorneo, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 130, 170, 30));

        Categoria1.setFont(new java.awt.Font("Waree", 1, 18)); // NOI18N
        Categoria1.setText("Categoria ");
        jPanel1.add(Categoria1, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 80, -1, -1));

        Categoria2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "A", "B", "C", "D", "E" }));
        Categoria2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Categoria2ActionPerformed(evt);
            }
        });
        jPanel1.add(Categoria2, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 130, 90, 30));

        GenerarTorneo.setFont(new java.awt.Font("Waree", 1, 14)); // NOI18N
        GenerarTorneo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/torneo (1).png"))); // NOI18N
        GenerarTorneo.setText("Generar Torneo");
        GenerarTorneo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                GenerarTorneoMouseClicked(evt);
            }
        });
        jPanel1.add(GenerarTorneo, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 360, 200, 40));

        BotonRegistrar.setFont(new java.awt.Font("Waree", 1, 14)); // NOI18N
        BotonRegistrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/nota.png"))); // NOI18N
        BotonRegistrar.setText("Registra");
        BotonRegistrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonRegistrarMouseClicked(evt);
            }
        });
        jPanel1.add(BotonRegistrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 290, 140, 40));

        TablaTorneo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Equipo", "Estadio"
            }
        ));
        jScrollPane1.setViewportView(TablaTorneo);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, 280, 340));

        Pizarron.setEditable(false);
        Pizarron.setBackground(new java.awt.Color(0, 0, 0));
        Pizarron.setColumns(20);
        Pizarron.setFont(new java.awt.Font("Waree", 1, 12)); // NOI18N
        Pizarron.setForeground(new java.awt.Color(255, 255, 255));
        Pizarron.setRows(5);
        jScrollPane2.setViewportView(Pizarron);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 220, 280, 350));

        BotonRegresar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/regresar.png"))); // NOI18N
        BotonRegresar.setBorder(null);
        BotonRegresar.setBorderPainted(false);
        BotonRegresar.setContentAreaFilled(false);
        BotonRegresar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonRegresarMouseClicked(evt);
            }
        });
        jPanel1.add(BotonRegresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 460, -1, -1));

        Imagen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/torneo (3).png"))); // NOI18N
        jPanel1.add(Imagen, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 40, 130, 140));

        Anuncio.setFont(new java.awt.Font("Waree", 1, 18)); // NOI18N
        Anuncio.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        Anuncio.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel1.add(Anuncio, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 10, 350, 40));

        Contenedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/balon.jpg"))); // NOI18N
        jPanel1.add(Contenedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(626, 0, 240, 600));

        wallpaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cancha1.jpg"))); // NOI18N
        jPanel1.add(wallpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, 870, 620));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 870, 610));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    /**
     *
     * Este boton es para guardar los datos ingresados por el usuario despues de
     * ser registrados los muestra en un mostrar torneo
     */
    private void BotonRegistrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonRegistrarMouseClicked

        String nombreTorneo = NombreTorneo.getText();
        String categoria = Categoria2.getSelectedItem().toString(); 

        if (nombreTorneo.isEmpty()) {
          
            JOptionPane.showMessageDialog(this, 
                    "Por favor, ingresa el nombre del torneo.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            
        } else {
            
            torneo = new Torneo(nombreTorneo, categoria);

            // Mostrar los valores registrados en una etiqueta
            String nombreTorneoRegistrado = torneo.getNombreTorneo();
            String categoriaRegistrada = torneo.getCategoria();

         Anuncio.setText(nombreTorneoRegistrado      + 
                 "Categoria"    +   categoriaRegistrada);
            
        }
        
    }//GEN-LAST:event_BotonRegistrarMouseClicked

    /**
     * botón y el código asociado generan los enfrentamientos para un torneo 
     * con una lista de equipos y los muestra en un componente de interfaz 
     * de usuario. 
     * 
     */
    private void GenerarTorneoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_GenerarTorneoMouseClicked

    if (modeloTable.getRowCount() == 0) {
       
        JOptionPane.showMessageDialog(this, 
                "No se puede generar el torneo cuando no hay equipos.", 
                "Error", JOptionPane.ERROR_MESSAGE);
       
        return;
    }
    
    List<String> equipos = new ArrayList<>();

    for (int i = 0; i < modeloTable.getRowCount(); i++) {
       
        String equipo = modeloTable.getValueAt(i, 0).toString();
      
        equipos.add(equipo);
    }

    List<String> enfrentamientos = new ArrayList<>();

    if (equipos.size() % 2 != 0) {
        equipos.add("Descanso");
    }

    int numRondas = equipos.size();
    int numEquipos = equipos.size();

    for (int ronda = 0; ronda < numRondas - 1; ronda++) {
        int equipoFijoIndex = ronda % numEquipos;
        String equipoFijo = equipos.get(equipoFijoIndex);

        for (int i = 0; i < numEquipos / 2; i++) {
            int equipo1Index = (ronda + i + 1) % numEquipos;
            int equipo2Index = (numEquipos - 1 - i + ronda) % numEquipos;

            String equipo1 = equipos.get(equipo1Index);
            String equipo2 = equipos.get(equipo2Index);

            if (!equipo1.equals(equipo2)) {
                String enfrentamiento = equipo1 + " vs " + equipo2;
                enfrentamientos.add(enfrentamiento);
            }
        }

        String enfrentamientoFijo = equipoFijo + " vs Descanso";
        enfrentamientos.add(enfrentamientoFijo);
    }

    for (String enfrentamiento : enfrentamientos) {
        Pizarron.append(enfrentamiento + "\n");
    }   
    }//GEN-LAST:event_GenerarTorneoMouseClicked

    /**
     * al hacer clic en este botón, se oculta la ventana actual y se muestra la 
     * vista del menú, lo que permite al usuario regresar a la pantalla 
     * o menú anterior.
     *  
     */
    private void BotonRegresarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonRegresarMouseClicked
       
        this.setVisible(false);
        this.menuVista.setVisible(true);
    }//GEN-LAST:event_BotonRegresarMouseClicked

    private void Categoria2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Categoria2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Categoria2ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Anuncio;
    private javax.swing.JButton BotonRegistrar;
    private javax.swing.JButton BotonRegresar;
    private javax.swing.JLabel Categoria1;
    private javax.swing.JComboBox<String> Categoria2;
    private javax.swing.JLabel Contenedor;
    private javax.swing.JButton GenerarTorneo;
    private javax.swing.JLabel Imagen;
    private javax.swing.JTextField NombreTorneo;
    private javax.swing.JTextArea Pizarron;
    private javax.swing.JTable TablaTorneo;
    private javax.swing.JLabel Titulo;
    private javax.swing.JLabel Titulo2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel wallpaper;
    // End of variables declaration//GEN-END:variables
}
