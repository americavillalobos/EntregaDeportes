/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:26/05/2023
*Fecha de actualización:23/06/2023
*Descripción:Esta es la ventana principal es el menú
 */
package view;

import entity.Equipo;
import entity.Arbitro;
import entity.Entrenador;
import entity.Jugador;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

/**
 * En esta parte del código define las variables y objetos necesarios para 
 * administrar diferentes vistas y listas de datos relacionados con árbitros,
 * entrenadores, equipos, torneos y jugadores en la aplicación.
 * 
 */

public class MenuVista extends javax.swing.JFrame {

    public List<Arbitro> listaArbitro;
    private VistaArbitro vistaArbritro;

    public List<Entrenador> listaEntrenador;
    private VistaEntrenador vistaEntrenador;

    public List<Equipo> listaEquipo;
    private VistaEquipo vistaEquipo;
    
    private VistaTorneo vistaTorneo;

    public List<Jugador> listaJugador;
    private VistaJugador vistaJugador;
    
    /**
     * el constructor de la clase MenuVista realiza inicializaciones y 
     * configuraciones iniciales, como la creación de listas vacías para 
     * almacenar objetos de diferentes tipos, y establece una imagen de 
     * fondo en el componente wallpaper.
     */
    public MenuVista() {
        initComponents();
        listaArbitro = new ArrayList<>(); 
        listaEntrenador = new ArrayList<>(); 
        listaEquipo = new ArrayList<>();
        listaJugador = new ArrayList<>();
 
       
        setResizable(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Fondo = new javax.swing.JPanel();
        Titulo1 = new javax.swing.JLabel();
        BotonDatosEquipo = new javax.swing.JButton();
        BotonDatosJugador = new javax.swing.JButton();
        BotonDatosArbitro = new javax.swing.JButton();
        BotonDatosEntrenador = new javax.swing.JButton();
        BotonTorneo = new javax.swing.JButton();
        Imagen = new javax.swing.JLabel();
        Botón_salir = new javax.swing.JButton();
        wallpaper = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Fondo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Titulo1.setFont(new java.awt.Font("Waree", 1, 48)); // NOI18N
        Titulo1.setForeground(new java.awt.Color(255, 255, 255));
        Titulo1.setText("Torneo");
        Fondo.add(Titulo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 30, 200, 70));

        BotonDatosEquipo.setFont(new java.awt.Font("Waree", 1, 14)); // NOI18N
        BotonDatosEquipo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/equipo (2).png"))); // NOI18N
        BotonDatosEquipo.setText("Datos del Equipo");
        BotonDatosEquipo.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        BotonDatosEquipo.setBorderPainted(false);
        BotonDatosEquipo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BotonDatosEquipoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BotonDatosEquipoMouseExited(evt);
            }
        });
        BotonDatosEquipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonDatosEquipoActionPerformed(evt);
            }
        });
        Fondo.add(BotonDatosEquipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 150, 230, -1));

        BotonDatosJugador.setFont(new java.awt.Font("Waree", 1, 14)); // NOI18N
        BotonDatosJugador.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/jugadoresdefutbol.png"))); // NOI18N
        BotonDatosJugador.setText("Datos del jugador");
        BotonDatosJugador.setBorderPainted(false);
        BotonDatosJugador.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BotonDatosJugadorMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BotonDatosJugadorMouseExited(evt);
            }
        });
        BotonDatosJugador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonDatosJugadorActionPerformed(evt);
            }
        });
        Fondo.add(BotonDatosJugador, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 200, 230, -1));

        BotonDatosArbitro.setFont(new java.awt.Font("Waree", 1, 14)); // NOI18N
        BotonDatosArbitro.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/arbitro.png"))); // NOI18N
        BotonDatosArbitro.setText("Datos del Árbitro");
        BotonDatosArbitro.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        BotonDatosArbitro.setBorderPainted(false);
        BotonDatosArbitro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BotonDatosArbitroMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BotonDatosArbitroMouseExited(evt);
            }
        });
        BotonDatosArbitro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonDatosArbitroActionPerformed(evt);
            }
        });
        Fondo.add(BotonDatosArbitro, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 260, 230, -1));

        BotonDatosEntrenador.setFont(new java.awt.Font("Waree", 1, 14)); // NOI18N
        BotonDatosEntrenador.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/director.png"))); // NOI18N
        BotonDatosEntrenador.setText("Registrar Entrenador");
        BotonDatosEntrenador.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        BotonDatosEntrenador.setBorderPainted(false);
        BotonDatosEntrenador.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BotonDatosEntrenadorMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BotonDatosEntrenadorMouseExited(evt);
            }
        });
        BotonDatosEntrenador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonDatosEntrenadorActionPerformed(evt);
            }
        });
        Fondo.add(BotonDatosEntrenador, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 310, 230, -1));

        BotonTorneo.setFont(new java.awt.Font("Waree", 1, 14)); // NOI18N
        BotonTorneo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/torneo (1).png"))); // NOI18N
        BotonTorneo.setText("Registrar Torneo");
        BotonTorneo.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        BotonTorneo.setBorderPainted(false);
        BotonTorneo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonTorneoMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BotonTorneoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BotonTorneoMouseExited(evt);
            }
        });
        Fondo.add(BotonTorneo, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 360, 230, -1));

        Imagen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/encabezamiento.png"))); // NOI18N
        Fondo.add(Imagen, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 90, 70));

        Botón_salir.setBackground(new java.awt.Color(242, 242, 242));
        Botón_salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/salidadeemergencia.png"))); // NOI18N
        Botón_salir.setContentAreaFilled(false);
        Botón_salir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Botón_salirMouseClicked(evt);
            }
        });
        Fondo.add(Botón_salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 450, 110, 80));

        wallpaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/balon.jpg"))); // NOI18N
        Fondo.add(wallpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 440, 550));

        getContentPane().add(Fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 440, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
  /**
     * Este método oculta la ventana actual y muestra una nueva ventana
     * VistaEquipo. Si la ventana VistaEquipo ya existe, simplemente la muestra
     * sin crear una nueva instancia.
     *
     */
    private void BotonDatosEquipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonDatosEquipoActionPerformed
       
        this.setVisible(false);
        
        if (this.vistaEquipo == null) {
            this.vistaEquipo = new VistaEquipo(this);
            this.vistaEquipo.setVisible(true);
        
        } else {
            
            this.vistaEquipo.setVisible(true);
       
        }
    }//GEN-LAST:event_BotonDatosEquipoActionPerformed

    /**
     * Este método oculta la ventana actual y muestra una nueva ventana
     * VistaJugador. Si la ventana VistaJugador ya existe, simplemente la
     * muestra sin crear una nueva instancia.
     *
     */
    private void BotonDatosJugadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonDatosJugadorActionPerformed
       
        this.setVisible(false);
        
        if (this.vistaJugador == null) {
            
            this.vistaJugador = new VistaJugador(this);
            this.vistaJugador.setVisible(true);
            
        } else {
            
            this.vistaJugador.setVisible(true);
        }
    }//GEN-LAST:event_BotonDatosJugadorActionPerformed
    
     /**
     * Este método oculta la ventana actual y muestra una nueva ventana
     * VistaArbitro. Si la ventana VistaArbitro ya existe, simplemente la
     * muestra sin crear una nueva instancia.
     *
     */
    private void BotonDatosArbitroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonDatosArbitroActionPerformed
      
        this.setVisible(false);
        
       if (this.vistaArbritro == null) {
           
            this.vistaArbritro = new VistaArbitro(this);
            this.vistaArbritro.setVisible(true);
            
        } else {
           
            this.vistaArbritro.setVisible(true);
        
       }
    }//GEN-LAST:event_BotonDatosArbitroActionPerformed

     /**
     * Este método oculta la ventana actual y muestra una nueva ventana
     * VistaEntrenador. Si la ventana VistaEntrenador ya existe, simplemente la
     * muestra sin crear una nueva instancia.
     *
     */
    private void BotonDatosEntrenadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonDatosEntrenadorActionPerformed
        
        this.setVisible(false);
        
        if (this.vistaEntrenador == null) {
            
            this.vistaEntrenador = new VistaEntrenador(this);
            this.vistaEntrenador.setVisible(true);
            
        } else {
            
            this.vistaEntrenador.setVisible(true);
        
        }
    }//GEN-LAST:event_BotonDatosEntrenadorActionPerformed
    
    /**
     *
     * Este es el boton salir finaliza el programa
     */
    private void Botón_salirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Botón_salirMouseClicked
  
        int opcion = JOptionPane.showConfirmDialog(this, 
       "¿Estás seguro de que quieres salir?", "Confirmar salida", 
       JOptionPane.YES_NO_OPTION);

    if (opcion == JOptionPane.YES_OPTION) {
        
        System.exit(0);
    }
    
    }//GEN-LAST:event_Botón_salirMouseClicked
    
    /**
     * 
     * Cuando el puntero del mouse entra en el área del botón,
     * el color de fondo del botón cambia a cyan, proporcionando 
     * una indicación visual de que el mouse está sobre el botón. 
     */
    private void BotonDatosEquipoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonDatosEquipoMouseEntered
       
      this.BotonDatosEquipo.setBackground(Color.CYAN);
      
    }//GEN-LAST:event_BotonDatosEquipoMouseEntered

    /**
     * código mencionada restablece el color de fondo del botón al valor
     * predeterminado del sistema
     * 
     */
    private void BotonDatosEquipoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonDatosEquipoMouseExited
       
     this.BotonDatosEquipo.setBackground(UIManager.getColor("control"));
     
    }//GEN-LAST:event_BotonDatosEquipoMouseExited
   
    /**
     * 
     * cuando se hace clic en el botón "BotonTorneo", la ventana actual se 
     * oculta y se crea una nueva ventana VistaTorneo, que se muestra en 
     * la pantalla. Esto permite cambiar de una ventana a otra en la interfaz
     * gráfica de tu aplicación. 
     */
    private void BotonTorneoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonTorneoMouseClicked
      
        this.setVisible(false);
        this.vistaTorneo = new VistaTorneo(this); 
        this.vistaTorneo.setVisible(true);
        
    }//GEN-LAST:event_BotonTorneoMouseClicked

    /**
     * 
     * Cuando el puntero del mouse entra en el área del botón,
     * el color de fondo del botón cambia a cyan, proporcionando 
     * una indicación visual de que el mouse está sobre el botón. 
     */
    private void BotonDatosJugadorMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonDatosJugadorMouseEntered
      
        this.BotonDatosJugador.setBackground(Color.CYAN);  
        
    }//GEN-LAST:event_BotonDatosJugadorMouseEntered

    /**
     * código mencionada restablece el color de fondo del botón al valor
     * predeterminado del sistema
     * 
     */
    private void BotonDatosJugadorMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonDatosJugadorMouseExited
       
    this.BotonDatosJugador.setBackground(UIManager.getColor("control"));
        
    }//GEN-LAST:event_BotonDatosJugadorMouseExited

     /**
     * 
     * Cuando el puntero del mouse entra en el área del botón,
     * el color de fondo del botón cambia a cyan, proporcionando 
     * una indicación visual de que el mouse está sobre el botón. 
     */
    private void BotonDatosArbitroMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonDatosArbitroMouseEntered
      
      this.BotonDatosArbitro.setBackground(Color.CYAN); 
        
    }//GEN-LAST:event_BotonDatosArbitroMouseEntered

     /**
     * código mencionada restablece el color de fondo del botón al valor
     * predeterminado del sistema
     * 
     */
    private void BotonDatosArbitroMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonDatosArbitroMouseExited
       
    this.BotonDatosArbitro.setBackground(UIManager.getColor("control"));
         
    }//GEN-LAST:event_BotonDatosArbitroMouseExited

     /**
     * 
     * Cuando el puntero del mouse entra en el área del botón,
     * el color de fondo del botón cambia a cyan, proporcionando 
     * una indicación visual de que el mouse está sobre el botón. 
     */
    private void BotonDatosEntrenadorMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonDatosEntrenadorMouseEntered
       
        this.BotonDatosEntrenador.setBackground(Color.CYAN);
        
    }//GEN-LAST:event_BotonDatosEntrenadorMouseEntered

     /**
     * código mencionada restablece el color de fondo del botón al valor
     * predeterminado del sistema
     * 
     */
    private void BotonDatosEntrenadorMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonDatosEntrenadorMouseExited
        
  this.BotonDatosEntrenador.setBackground(UIManager.getColor("control"));
         
    }//GEN-LAST:event_BotonDatosEntrenadorMouseExited

     /**
     * 
     * Cuando el puntero del mouse entra en el área del botón,
     * el color de fondo del botón cambia a cyan, proporcionando 
     * una indicación visual de que el mouse está sobre el botón. 
     */
    private void BotonTorneoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonTorneoMouseEntered
       
         this.BotonTorneo.setBackground(Color.CYAN);
         
    }//GEN-LAST:event_BotonTorneoMouseEntered

     /**
     * código mencionada restablece el color de fondo del botón al valor
     * predeterminado del sistema
     * 
     */
    private void BotonTorneoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonTorneoMouseExited
       
  this.BotonTorneo.setBackground(UIManager.getColor("control"));
  
    }//GEN-LAST:event_BotonTorneoMouseExited

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(() -> {
            new MenuVista().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotonDatosArbitro;
    private javax.swing.JButton BotonDatosEntrenador;
    private javax.swing.JButton BotonDatosEquipo;
    private javax.swing.JButton BotonDatosJugador;
    private javax.swing.JButton BotonTorneo;
    private javax.swing.JButton Botón_salir;
    private javax.swing.JPanel Fondo;
    private javax.swing.JLabel Imagen;
    private javax.swing.JLabel Titulo1;
    private javax.swing.JLabel wallpaper;
    // End of variables declaration//GEN-END:variables
}
