/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:26/05/2023
*Fecha de actualización:27/05/2023
*Descripción:Service del jugador
 */
package service;

import entity.Jugador;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public interface IJugadorService {

    /**
     *El método crea un jugador
     * @param lista
     * @param jugador
     */
    public void crearRegistro(List<Jugador> lista, Jugador jugador);

    /**
     *El método elimina un jugador
     * @param lista
     * @param nombre
     */
    public void eliminarRegistro(List<Jugador> lista, String nombre);

    /**
     *El método actualiza un jugador
     * @param lista
     * @param jugador
     */
    public void actualizarRegistro(List<Jugador> lista, Jugador jugador);

    /**
     *El método muestra un jugador
     * @param lista
     * @param modelo
     */
    public void mostrarRegistro(List<Jugador> lista, DefaultTableModel modelo);

}
