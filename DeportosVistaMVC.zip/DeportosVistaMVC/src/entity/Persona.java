/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:17/05/2023
*Fecha de actualización:17/05/2023
*Descripción:.Es la clase padre
 */
package entity;

/**
 *
 * Se declararon los atributos de la clase con sus getter and setter
 */
public class Persona {

    private String nombre;

    public Persona() {
    }

    public Persona(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

}
