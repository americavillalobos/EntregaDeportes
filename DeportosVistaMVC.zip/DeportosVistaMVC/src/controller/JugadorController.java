/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:26/05/2023
*Fecha de actualización:27/05/2023
*Descripción:controller del jugador
 */
package controller;

import entity.Jugador;
import service.IJugadorService;
import service.JugadorServiceImpl;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class JugadorController {

    IJugadorService service = new JugadorServiceImpl();

    /**
     * El método crea un jugador
     * @param lista
     * @param jugador 
     */
    public void crearRegistro(List<Jugador> lista, Jugador jugador) {
        service.crearRegistro(lista, jugador);
    }

    /**
     * El método elimina un jugador
     * @param lista
     * @param nombre 
     */
    public void eliminarRegistro(List<Jugador> lista, String nombre) {
        service.eliminarRegistro(lista, nombre);
    }

    /**
     * El método actualiza un jugador
     * @param lista
     * @param jugador 
     */
    public void actualizarRegistro(List<Jugador> lista, Jugador jugador) {
        service.actualizarRegistro(lista, jugador);
    }

    /**
     * /El método muestra un jugador
     * @param lista
     * @param modelo 
     */
    public void mostrarRegistro(List<Jugador> lista, DefaultTableModel modelo) {
        service.mostrarRegistro(lista, modelo);
    }

}
