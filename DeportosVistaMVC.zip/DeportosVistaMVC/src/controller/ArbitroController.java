/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:26/05/2023
*Fecha de actualización:27/05/2023
*Descripción:controller del árbitro
 */
package controller;

import entity.Arbitro;
import service.ArbitroServiceImpl;
import service.IArbitroService;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class ArbitroController {

    IArbitroService service = new ArbitroServiceImpl();

    /**
     * El método crea un árbitro
     * @param lista
     * @param arbitro 
     */
    public void crearRegistro(List<Arbitro> lista, Arbitro arbitro) {
        service.crearRegistro(lista, arbitro);
    }
    
    /**
     * El método elimina un árbitro
     * @param lista
     * @param nombre 
     */
    public void eliminarRegistro(List<Arbitro> lista, String nombre) {
        service.eliminarRegistro(lista, nombre);
    }

    /**
     * El método actualiza un árbitro
     * @param lista
     * @param arbitro 
     */
    public void actualizarRegistro(List<Arbitro> lista, Arbitro arbitro) {
        service.actualizarRegistro(lista, arbitro);
    }

    /**
     * El método muestra un árbitro
     * @param lista
     * @param modelo 
     */
    public void mostrarRegistro(List<Arbitro> lista, DefaultTableModel modelo) {
        service.mostrarRegistro(lista, modelo);
    }

}
