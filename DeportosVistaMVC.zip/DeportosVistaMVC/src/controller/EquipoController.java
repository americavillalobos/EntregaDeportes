/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:26/05/2023
*Fecha de actualización:27/05/2023
*Descripción:Controller equipo
 */
package controller;

import entity.Equipo;
import service.EquipoServiceImpl;
import service.IEquipoService;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class EquipoController {

    IEquipoService service = new EquipoServiceImpl();

    /**
     *El método crea un equipo
     * @param lista
     * @param equipo 
     */
    public void crearRegistro(List<Equipo> lista, Equipo equipo) {
        service.crearRegistro(lista, equipo);
    }

    /**
     *El método elimina un equipo
     * @param lista
     * @param nombre 
     */
    public void eliminarRegistro(List<Equipo> lista, String nombre) {
        service.eliminarRegistro(lista, nombre);
    }

    /**
     * /El método actualiza un equipo
     * @param lista
     * @param equipo 
     */
    public void actualizarRegistro(List<Equipo> lista, Equipo equipo) {
        service.actualizarRegistro(lista, equipo);
    }

    /**
     *El método actualiza un equipo
     * @param lista
     * @param modelo 
     */
    public void mostrarRegistro(List<Equipo> lista, DefaultTableModel modelo) {
        service.mostrarRegistro(lista, modelo);
    }

}
