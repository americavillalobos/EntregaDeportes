/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:26/05/2023
*Fecha de actualización:27/05/2023
*Descripción:clase model Entrenador
 */
package model;

import entity.Entrenador;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class IEntrenadorModel implements EntrenadorModelImpl {

    /**
     * El método crea un entrenador
     * @param lista
     * @param entrenador 
     */
    @Override
    public void crearRegistro(List<Entrenador> lista, Entrenador entrenador) {
        lista.add(entrenador);

    }

    /**
     *El método elimina un entrenador
     * @param lista
     * @param nombre 
     */
    @Override
    public void eliminarRegistro(List<Entrenador> lista, String nombre) {
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getNombre().compareTo(nombre) == 0) {
                lista.remove(i);

                break;
            }
        }
    }

    /**
     * El método actualiza un entrenador
     * @param lista
     * @param entrenador 
     */
    @Override
    public void actualizarRegistro(List<Entrenador> lista, Entrenador entrenador) {
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getNombre().compareTo(entrenador.getNombre()) == 0) {
                lista.set(i, entrenador);
                break;
            }
        }
    }

    /**
     * El método muestra un entrenador
     * @param lista
     * @param modelo 
     */
    @Override
    public void mostrarRegistro(List<Entrenador> lista, DefaultTableModel modelo) {
        modelo.setRowCount(0);
        for (int i = 0; i < lista.size(); i++) {
            Object[] fila = new Object[2];

            fila[0] = lista.get(i).getNombre();
            fila[1] = lista.get(i).getEquipo();

            modelo.addRow(fila);
        }
    }
}
