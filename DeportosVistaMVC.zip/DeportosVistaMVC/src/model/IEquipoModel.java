/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:26/05/2023
*Fecha de actualización:27/05/2023
*Descripción:Model Equipo
 */
package model;

import entity.Equipo;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public interface IEquipoModel {
    
    /**
     * El método crea un equipo
     * @param lista
     * @param equipo 
     */
    public void crearRegistro(List<Equipo> lista, Equipo equipo);

    /**
     * El método elimina un equipo
     * @param lista
     * @param nombre 
     */
    public void eliminarRegistro(List<Equipo> lista, String nombre);

     /**
      * El método actualiza un equipo
      * @param lista
      * @param equipo 
      */
    public void actualizarRegistro(List<Equipo> lista, Equipo equipo);

    /**
     * El método muestra un entrenador
     * @param lista
     * @param modelo 
     */
    public void mostrarRegistro(List<Equipo> lista, DefaultTableModel modelo);

}
